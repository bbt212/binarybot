import flet as ft
import threading
import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import random

class TradingBot:
    def __init__(self, initial_stake, stop_loss, take_profit, account_type, dynamic_stake_enabled=False, status_callback=None):
        self.driver = None
        self.email = 'binarybottradingtraining@gmail.com'
        self.password = 'dinesh1212#D1234'
        self.initial_balance = None
        self.current_balance = None
        self.current_stake = None
        self.initial_stake = initial_stake
        self.consecutive_losses = 0
        self.stop_loss_amount = float(stop_loss)
        self.take_profit_amount = float(take_profit)
        self.account_type = account_type
        self.is_running = False
        self.dynamic_stake_enabled = dynamic_stake_enabled
        self.trade_count = 0
        self.last_trade_result = None
        self.status_callback = status_callback

    def log(self, message):
        if self.status_callback:
            filtered_messages = [
                "Login successful",
                "Waiting 40 seconds for manual switch",
                "Current Balance:",
                "Starting Balance:",
                "Stop Loss at:",
                "Target Profit at:",
                "Trade #",
                "Placing",
                "Profit from",
                "Loss from",
                "Stop Loss hit",
                "Target reached",
                "Bot stopped"
            ]
            if any(msg in message for msg in filtered_messages):
                self.status_callback(message)

    def login(self):
        try:
            self.driver = uc.Chrome()
            self.driver.maximize_window()
            self.driver.get("https://qxbroker.com/en/sign-in")
            time.sleep(5)

            email_field = self.driver.find_element(By.XPATH, '//*[@id="tab-1"]/form/div[1]/input')
            password_field = self.driver.find_element(By.XPATH, '//*[@id="tab-1"]/form/div[2]/input')
            email_field.send_keys(self.email)
            password_field.send_keys(self.password)
            login_button = self.driver.find_element(By.XPATH, '//*[@id="tab-1"]/form/button')
            login_button.click()
            time.sleep(10)

            if "trade" not in self.driver.current_url:
                return False

            self.log("Login successful")

            if self.account_type == "DEMO":
                self.driver.get("https://qxbroker.com/en/demo-trade")
            else:
                self.driver.get("https://qxbroker.com/en/trade")

            self.log("Waiting 40 seconds for manual switch...")
            time.sleep(40)
            return True

        except Exception:
            if self.driver:
                self.driver.quit()
                self.driver = None
            return False

    def get_balance(self):
        try:
            balance_element = WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="root"]/div/div[1]/header/div[8]/div[2]/div/div[3]/div[2]'))
            )
            balance_text = balance_element.text.strip().replace("₹", "").replace(",", "")
            return float(balance_text)
        except:
            return 0.0

    def calculate_stake(self):
        if self.last_trade_result == 'loss':
            martingale_stake = self.current_stake * 2
            max_allowed_stake = self.current_balance * 0.5
            return min(martingale_stake, max_allowed_stake)
            
        if self.trade_count <= 2:
            return self.initial_stake
        
        if self.dynamic_stake_enabled:
            min_stake = self.initial_stake
            max_stake = self.initial_stake * 2
            return random.randint(int(min_stake), int(max_stake))
        
        return self.initial_stake

    def set_stake(self, amount):
        stake_input = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="root"]/div/div[1]/main/div[2]/div[1]/div/div[5]/div[2]/div/div/input'))
        )
        stake_input.click()
        stake_input.send_keys(Keys.CONTROL + "a")
        stake_input.send_keys(str(int(amount)))
        time.sleep(1)

    def place_trade(self, direction, timer_value):
        try:
            self.trade_count += 1
            self.current_stake = self.calculate_stake()
            
            button_xpath = '//*[@id="root"]/div/div[1]/main/div[2]/div[1]/div/div[6]/div[1]/button' if direction == "Up" else '//*[@id="root"]/div/div[1]/main/div[2]/div[1]/div/div[6]/div[4]/button'
            button = WebDriverWait(self.driver, 15).until(
                EC.element_to_be_clickable((By.XPATH, button_xpath))
            )
            
            self.set_stake(self.current_stake)
            self.log(f"Trade #{self.trade_count} - Placing '{direction}' trade with stake: ${self.current_stake}")
            
            button.click()
            time.sleep(timer_value)

            new_balance = self.get_balance()
            if new_balance > self.current_balance:
                profit = new_balance - self.current_balance
                self.log(f"Profit from '{direction}' trade: ${profit:.2f}")
                self.last_trade_result = 'win'
                self.consecutive_losses = 0
            else:
                loss = self.current_balance - new_balance
                self.log(f"Loss from '{direction}' trade: ${loss:.2f}")
                self.last_trade_result = 'loss'
                self.consecutive_losses += 1

            self.current_balance = new_balance

        except Exception:
            time.sleep(30)

    def start_trading(self):
        if not self.login():
            return

        self.is_running = True
        self.initial_balance = self.get_balance()
        
        if self.initial_balance == 0:
            return

        self.current_balance = self.initial_balance
        self.current_stake = self.initial_stake
        self.trade_count = 0
        self.last_trade_result = None
        self.consecutive_losses = 0

        target_balance = self.initial_balance + self.take_profit_amount
        stop_balance = self.initial_balance - self.stop_loss_amount

        self.log(f"Starting Balance: ${self.initial_balance}")
        self.log(f"Stop Loss at: ${stop_balance}")
        self.log(f"Target Profit at: ${target_balance}")

        trade_direction = "Up"
        timer_value = 25

        while self.is_running and self.current_balance > stop_balance and self.current_balance < target_balance:
            try:
                self.place_trade(trade_direction, timer_value)
                trade_direction = "Down" if trade_direction == "Up" else "Up"
                
                if not self.is_running:
                    break
                    
                time.sleep(10)
            except Exception:
                time.sleep(30)

        if self.current_balance <= stop_balance:
            self.log(f"Stop Loss hit - Final: ${self.current_balance}")
        elif self.current_balance >= target_balance:
            self.log(f"Target reached - Final: ${self.current_balance}")

        self.stop()

    def stop(self):
        self.is_running = False
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            finally:
                self.driver = None
        self.log("Bot stopped")

def main(page: ft.Page):
    page.title = "Binary Bot Traders"
    page.theme_mode = "dark"
    page.window_width = 400
    page.window_height = 800
    page.padding = 20

    license_input = ft.TextField(
        label="License Key",
        border_radius=10,
        width=300
    )

    account_type = ft.Dropdown(
        width=300,
        label="Account Type",
        options=[
            ft.dropdown.Option("DEMO"),
            ft.dropdown.Option("REAL")
        ],
        value="DEMO"
    )

    stake_input = ft.TextField(
        label="Initial Stake ($)",
        border_radius=10,
        width=300,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    target_profit = ft.TextField(
        label="Target Profit Amount ($)",
        border_radius=10,
        width=300,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    stop_loss = ft.TextField(
        label="Stop Loss Amount ($)",
        border_radius=10,
        width=300,
        keyboard_type=ft.KeyboardType.NUMBER
    )

    dynamic_stake = ft.Switch(
        label="Dynamic Stake",
        value=False
    )

    status_display = ft.TextField(
        multiline=True,
        read_only=True,
        min_lines=10,
        max_lines=10,
        width=300
    )

    bot_instance = None
    bot_thread = None

    def verify_license(license_key):
        return license_key == "121231"

    def update_status(message):
        status_display.value = f"{status_display.value}\n{message}" if status_display.value else message
        page.update()

    def start_bot(e):
        nonlocal bot_instance, bot_thread

        if not verify_license(license_input.value):
            update_status("Invalid license key!")
            return

        try:
            initial_stake = float(stake_input.value)
            target_profit_val = float(target_profit.value)
            stop_loss_val = float(stop_loss.value)

            if initial_stake <= 0 or target_profit_val <= 0 or stop_loss_val <= 0:
                update_status("Values must be greater than zero!")
                return

            start_button.disabled = True
            stop_button.disabled = False
            page.update()

            bot_instance = TradingBot(
                initial_stake=initial_stake,
                stop_loss=stop_loss_val,
                take_profit=target_profit_val,
                account_type=account_type.value,
                dynamic_stake_enabled=dynamic_stake.value,
                status_callback=update_status
            )

            bot_thread = threading.Thread(target=bot_instance.start_trading)
            bot_thread.daemon = True
            bot_thread.start()

        except ValueError:
            update_status("Please enter valid numbers")
            start_button.disabled = False
            stop_button.disabled = True
            page.update()
        except Exception as e:
            update_status(f"Error: {str(e)}")
            start_button.disabled = False
            stop_button.disabled = True
            page.update()

    def stop_bot(e):
        nonlocal bot_instance
        if bot_instance:
            bot_instance.stop()
            start_button.disabled = False
            stop_button.disabled = True
            page.update()

    start_button = ft.ElevatedButton(
        "Start Bot",
        on_click=start_bot,
        style=ft.ButtonStyle(
            color=ft.colors.WHITE,
            bgcolor=ft.colors.GREEN
        ),
        width=140
    )

    stop_button = ft.ElevatedButton(
        "Stop Bot",
        on_click=stop_bot,
        style=ft.ButtonStyle(
            color=ft.colors.WHITE,
            bgcolor=ft.colors.RED
        ),
        disabled=True,
        width=140
    )

    page.add(
        ft.Column(
            controls=[
                ft.Text(
                    "BINARY BOT TRADERS",
                    size=24,
                    weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER
                ),
                license_input,
                account_type,
                stake_input,
                target_profit,
                stop_loss,
                dynamic_stake,
                ft.Row(
                    controls=[start_button, stop_button],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                status_display
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20
        )
    )

if __name__ == '__main__':
    ft.app(target=main)